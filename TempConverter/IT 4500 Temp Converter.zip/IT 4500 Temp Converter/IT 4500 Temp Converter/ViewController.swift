//
//  ViewController.swift
//  IT 4500 Temp Converter
//
//  Created by Tyron Allen on 10/21/14.
//  Copyright (c) 2014 Tyron Allen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


   
    
    @IBAction func Convert(sender: AnyObject) {
        
         var Farenheit: [UILabel]!
        
         weak var Celsius: UITextField!
       
        Farenheit = Celsius * 1.8 + 32;
        
        
        
    }
    
}

