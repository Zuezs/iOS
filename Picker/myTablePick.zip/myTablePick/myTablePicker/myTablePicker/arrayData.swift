//
//  arrayData.swift
//  myTablePicker
//
//  Created by Tyron Allen on 11/3/14.
//  Copyright (c) 2014 Tyron Allen. All rights reserved.
//

import UIKit

class arrayData: NSObject {
   
    func MyArray() -> NSMutableArray{
        let tableData:NSMutableArray = ["Java", "Python", "C++", "Ruby", "HTML", "PHP", "JavaScript", "Swift"]
        
        return tableData
        
    }
    
}
